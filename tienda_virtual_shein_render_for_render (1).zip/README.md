Tienda Virtual SHEIN - Paquete completo

Contenido:
- server/: backend Express + SQLite
- client/: frontend React (simple)

Configuraciones importantes:
- WhatsApp empresarial configurado: +57 3132573810
- Número de medios de pago: 3132893545
- Admin user: admin
- Admin pass: Juan2004**

Instrucciones rápidas:
1. En el root del proyecto: `npm install`
   (Esto instalará dependencias del backend.)
2. En la carpeta client: `npx create-react-app .` o instalar dependencias y ajustar si prefieres.
   Para simplicidad, el cliente incluido es un conjunto de archivos; puedes integrarlo en un CRA o usar tu builder preferido.
3. Iniciar el backend:
   - `node server/index.js`
4. Iniciar el cliente (si usas CRA): `npm start` dentro de /client

El backend corre por defecto en http://localhost:4000

Notas:
- Este paquete es una base funcional. Para producción se recomiendan:
  * Usar HTTPS
  * Configurar almacenamiento persistente (S3 u otro) para comprobantes
  * Usar variables de entorno para secretos y credenciales
  * Integrar una pasarela de pagos si quieres pagos automáticos

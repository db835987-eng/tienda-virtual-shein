import React, { useEffect, useState } from 'react';
import './styles.css';

const API = process.env.REACT_APP_API_URL || 'http://localhost:4000';

function formatPrice(v, currency='USD') {
  try { return new Intl.NumberFormat('es-CO', { style: 'currency', currency }).format(v); } catch(e) { return `${currency} ${v}`; }
}

export default function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [customer, setCustomer] = useState({ name:'', phone:'', city:'', address:''});
  const [paymentMethod, setPaymentMethod] = useState('Nequi');
  const [receiptFile, setReceiptFile] = useState(null);
  const [view, setView] = useState('home');

  useEffect(()=> {
    fetch(`${API}/api/products`).then(r=>r.json()).then(setProducts).catch(()=>{});
  },[]);

  function addToCart(p){
    setCart(c=>{
      const found = c.find(i=>i.id===p.id);
      if(found) return c.map(i=>i.id===p.id?{...i,qty:Math.min(i.qty+1,p.stock)}:i);
      return [...c, { id: p.id, title: p.title, price: p.price, currency: p.currency, qty:1 }];
    });
  }

  const subtotal = cart.reduce((a,b)=>a+b.price*b.qty,0);

  async function createOrder(){
    if(cart.length===0) return alert('Carrito vacío');
    if(!customer.name || !customer.phone || !customer.city || !customer.address) return alert('Completa tus datos');
    const form = new FormData();
    form.append('customer_name', customer.name);
    form.append('customer_phone', customer.phone);
    form.append('customer_city', customer.city);
    form.append('customer_address', customer.address);
    form.append('payment_method', paymentMethod);
    form.append('items', JSON.stringify(cart));
    if(receiptFile) form.append('receipt', receiptFile);
    const res = await fetch(`${API}/api/orders`, { method:'POST', body: form });
    const data = await res.json();
    if(!res.ok) return alert(data.error || 'Error creando orden');
    setCart([]);
    alert('Orden creada. Se abrirá WhatsApp para notificar al vendedor.');
    window.open(data.whatsappUrl, '_blank');
  }

  return (
    <div className="container">
      <header style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
        <h1>Tienda Virtual SHEIN</h1>
        <div>
          <button className="btn btn-primary" onClick={()=>setView('home')}>Tienda</button>
          <button className="btn" style={{marginLeft:8}} onClick={()=>setView('admin')}>Admin</button>
        </div>
      </header>

      {view==='home' && (
        <div style={{display:'flex',gap:16}}>
          <div style={{flex:3}}>
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12}}>
              {products.map(p=>(
                <div key={p.id} className="card">
                  <img src={p.images?.[0]} alt={p.title} style={{width:'100%',height:160,objectFit:'cover',borderRadius:6}} />
                  <h3 style={{marginTop:8}}>{p.title}</h3>
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                    <strong>{formatPrice(p.price,p.currency)}</strong>
                    <span style={{fontSize:12,color:'#6b7280'}}>Stock: {p.stock}</span>
                  </div>
                  <button className="btn btn-green" style={{marginTop:8,width:'100%'}} onClick={()=>addToCart(p)} disabled={p.stock===0}>Añadir</button>
                </div>
              ))}
            </div>
          </div>

          <aside style={{flex:1}}>
            <div className="card">
              <h3>Tu carrito</h3>
              {cart.length===0 ? <p>Carrito vacío</p> : cart.map(it=>(
                <div key={it.id} style={{marginBottom:8}}>
                  <div style={{fontWeight:600}}>{it.title}</div>
                  <div style={{fontSize:12}}>{it.qty} x {formatPrice(it.price,it.currency)}</div>
                </div>
              ))}
              <hr />
              <div style={{display:'flex',justifyContent:'space-between',marginTop:8}}>
                <strong>Subtotal</strong><strong>{formatPrice(subtotal)}</strong>
              </div>

              <div style={{marginTop:12}}>
                <h4>Tus datos</h4>
                <input placeholder="Nombre" value={customer.name} onChange={e=>setCustomer({...customer,name:e.target.value})} className="w-full" style={{width:'100%',padding:8,marginTop:6}}/>
                <input placeholder="Teléfono" value={customer.phone} onChange={e=>setCustomer({...customer,phone:e.target.value})} className="w-full" style={{width:'100%',padding:8,marginTop:6}}/>
                <input placeholder="Ciudad" value={customer.city} onChange={e=>setCustomer({...customer,city:e.target.value})} className="w-full" style={{width:'100%',padding:8,marginTop:6}}/>
                <input placeholder="Dirección" value={customer.address} onChange={e=>setCustomer({...customer,address:e.target.value})} className="w-full" style={{width:'100%',padding:8,marginTop:6}}/>
                <div style={{marginTop:8}}>
                  <label>Método de pago</label>
                  <select value={paymentMethod} onChange={e=>setPaymentMethod(e.target.value)} style={{width:'100%',padding:8,marginTop:6}}>
                    <option>Nequi</option>
                    <option>Daviplata</option>
                    <option>dale</option>
                  </select>
                </div>
                <div style={{marginTop:8}}>
                  <label>Comprobante (opcional)</label>
                  <input type="file" onChange={e=>setReceiptFile(e.target.files?.[0])} />
                </div>
                <button className="btn btn-primary" style={{marginTop:12,width:'100%'}} onClick={createOrder}>Confirmar y pagar</button>
              </div>
            </div>
          </aside>
        </div>
      )}

      {view==='admin' && <AdminPanel api={API} onLogout={()=>setView('home')} />}
    </div>
  );
}

function AdminPanel({api, onLogout}) {
  const [logged, setLogged] = useState(false);
  const [user, setUser] = useState('admin');
  const [pass, setPass] = useState('');
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);

  async function login() {
    const res = await fetch(`${api}/api/admin/login`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({user,pass}) });
    if(res.ok) { setLogged(true); loadOrders(); return; }
    alert('Acceso denegado');
  }

  async function loadOrders() {
    setLoading(true);
    const res = await fetch(`${api}/api/admin/orders`);
    if(!res.ok) { setLoading(false); return; }
    const data = await res.json();
    setOrders(data);
    setLoading(false);
  }

  async function changeStatus(id, status) {
    await fetch(`${api}/api/admin/orders/${id}/status`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({status}) });
    loadOrders();
  }

  async function exportExcel() {
    window.location.href = `${api}/api/admin/export`;
  }

  if(!logged) {
    return (
      <div className="card" style={{maxWidth:400}}>
        <h3>Login Admin - Tienda Virtual SHEIN</h3>
        <input placeholder="Usuario" value={user} onChange={e=>setUser(e.target.value)} style={{width:'100%',padding:8,marginTop:8}} />
        <input placeholder="Contraseña" value={pass} onChange={e=>setPass(e.target.value)} type="password" style={{width:'100%',padding:8,marginTop:8}} />
        <div style={{display:'flex',gap:8,marginTop:8}}>
          <button className="btn btn-primary" onClick={login}>Entrar</button>
          <button className="btn" onClick={()=>{ setUser('admin'); setPass(''); }}>Reset</button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
        <h2>Panel de Pedidos — Tienda Virtual SHEIN</h2>
        <div>
          <button className="btn" onClick={exportExcel}>Exportar Excel</button>
          <button className="btn" style={{marginLeft:8}} onClick={async ()=>{ await fetch(`${api}/api/admin/logout`,{method:'POST'}); setLogged(false); onLogout(); }}>Cerrar sesión</button>
        </div>
      </div>

      <div className="card">
        {loading ? <p>Cargando...</p> : (
          <table>
            <thead><tr>
              <th>Pedido</th><th>Cliente</th><th>Tel</th><th>Ciudad</th><th>Dirección</th><th>Total</th><th>Pago</th><th>Status</th><th>Comprobante</th><th>WhatsApp</th>
            </tr></thead>
            <tbody>
              {orders.map(o=>(
                <tr key={o.id}>
                  <td>{o.id}<br/><small>{new Date(o.created_at).toLocaleString()}</small></td>
                  <td>{o.customer_name}</td>
                  <td>{o.customer_phone}</td>
                  <td>{o.customer_city}</td>
                  <td>{o.customer_address}</td>
                  <td>{o.total}</td>
                  <td>{o.payment_method}</td>
                  <td>
                    <select value={o.status} onChange={e=>changeStatus(o.id,e.target.value)}>
                      <option>Pendiente</option>
                      <option>Pagado</option>
                      <option>Enviado</option>
                    </select>
                  </td>
                  <td>{o.receipt_path ? <a href={`${api}${o.receipt_path}`} target="_blank" rel="noreferrer">Ver</a> : '—'}</td>
                  <td>
                    <a className="btn btn-green" href={`https://wa.me/5731325737810?text=${encodeURIComponent('Hola, referente al pedido ' + o.id)}`} target="_blank" rel="noreferrer">WhatsApp</a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

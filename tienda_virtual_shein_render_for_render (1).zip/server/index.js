// server/index.js
const express = require('express');
const path = require('path');
const multer = require('multer');
const cors = require('cors');
const { nanoid } = require('nanoid');
const fs = require('fs');
const session = require('express-session');
const ExcelJS = require('exceljs');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json());
app.use(session({
  secret: 'tienda-secreta-2025',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 24*60*60*1000 }
}));

const WHATSAPP_NUMBER = '+5731325737810';
const PAYMENT_NUMBER = '3132893545';

const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${nanoid(6)}-${file.originalname.replace(/\s+/g,'_')}`)
});
const upload = multer({ storage });

// Public products
app.get('/api/products', (req, res) => {
  const rows = db.prepare('SELECT id,title,price,currency,sku,stock,image as images,description FROM products').all();
  const data = rows.map(r => ({ ...r, images: [r.images] }));
  res.json(data);
});

// Create order
app.post('/api/orders', upload.single('receipt'), (req, res) => {
  try {
    const { customer_name, customer_phone, customer_city, customer_address, payment_method, items } = req.body;
    if (!customer_name || !customer_phone || !customer_address || !customer_city || !payment_method || !items) {
      return res.status(400).json({ error: 'Faltan datos del pedido' });
    }
    const parsedItems = JSON.parse(items);
    const total = parsedItems.reduce((a,b) => a + b.price * b.qty, 0);
    const orderId = 'ORD-' + nanoid(8).toUpperCase();
    const createdAt = new Date().toISOString();
    const receiptPath = req.file ? `/uploads/${path.basename(req.file.path)}` : null;
    const insertOrder = db.prepare('INSERT INTO orders (id,customer_name,customer_phone,customer_city,customer_address,payment_method,total,status,created_at,receipt_path) VALUES (?,?,?,?,?,?,?,?,?,?)');
    insertOrder.run(orderId, customer_name, customer_phone, customer_city, customer_address, payment_method, total, 'Pendiente', createdAt, receiptPath);

    const insertItem = db.prepare('INSERT INTO order_items (order_id,product_id,title,price,qty) VALUES (?,?,?,?,?)');
    const stmt = db.transaction((itemsArr) => {
      for (const it of itemsArr) {
        insertItem.run(orderId, it.id, it.title, it.price, it.qty);
      }
    });
    stmt(parsedItems);

    // Build WhatsApp message
    const lines = [];
    lines.push(`Hola, tengo un pedido ${orderId}`);
    lines.push('');
    parsedItems.forEach(it => lines.push(`${it.qty} x ${it.title} — ${it.price} ${it.currency || ''}`));
    lines.push('');
    lines.push(`Total: ${total}`);
    lines.push(`Nombre: ${customer_name}`);
    lines.push(`Teléfono: ${customer_phone}`);
    lines.push(`Ciudad: ${customer_city}`);
    lines.push(`Dirección: ${customer_address}`);
    lines.push(`Medio de pago: ${payment_method}`);
    lines.push('Adjunto comprobante.');

    const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER.replace('+','')}?text=${encodeURIComponent(lines.join('\n'))}`;

    res.json({ orderId, whatsappUrl, receiptPath });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al crear la orden' });
  }
});

// Serve uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Simple auth - login
const ADMIN_USER = 'admin';
const ADMIN_PASS = 'Juan2004**';

app.post('/api/admin/login', (req, res) => {
  const { user, pass } = req.body;
  if (user === ADMIN_USER && pass === ADMIN_PASS) {
    req.session.admin = true;
    return res.json({ ok: true });
  }
  res.status(401).json({ error: 'Acceso denegado' });
});

app.post('/api/admin/logout', (req, res) => {
  req.session.destroy(()=>res.json({ ok: true }));
});

function requireAdmin(req, res, next) {
  if (req.session && req.session.admin) return next();
  return res.status(401).json({ error: 'Unauthorized' });
}

// Admin endpoints
app.get('/api/admin/orders', requireAdmin, (req, res) => {
  const orders = db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
  const items = db.prepare('SELECT * FROM order_items').all();
  const byOrder = orders.map(o => ({ ...o, items: items.filter(i => i.order_id === o.id) }));
  res.json(byOrder);
});

app.post('/api/admin/orders/:id/status', requireAdmin, (req, res) => {
  const id = req.params.id;
  const { status } = req.body;
  db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(status, id);
  res.json({ ok: true });
});

app.get('/api/admin/export', requireAdmin, async (req, res) => {
  const orders = db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
  const items = db.prepare('SELECT * FROM order_items').all();

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Pedidos');
  sheet.columns = [
    { header: 'OrderId', key: 'id', width: 20 },
    { header: 'Nombre', key: 'customer_name', width: 25 },
    { header: 'Telefono', key: 'customer_phone', width: 15 },
    { header: 'Ciudad', key: 'customer_city', width: 15 },
    { header: 'Direccion', key: 'customer_address', width: 30 },
    { header: 'Total', key: 'total', width: 10 },
    { header: 'Metodo pago', key: 'payment_method', width: 15 },
    { header: 'Status', key: 'status', width: 12 },
    { header: 'Created At', key: 'created_at', width: 25 },
  ];
  for (const o of orders) {
    sheet.addRow(o);
    const its = items.filter(i => i.order_id === o.id);
    for (const it of its) {
      sheet.addRow({ id: '', customer_name: `  -> ${it.qty} x ${it.title}`, created_at: '' });
    }
  }
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename=pedidos.xlsx');
  await workbook.xlsx.write(res);
  res.end();
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));

// Export app for tests (optional)
module.exports = app;

// server/db.js
const Database = require('better-sqlite3');
const path = require('path');
const db = new Database(path.join(__dirname, 'tienda.db'));

db.exec(`
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  title TEXT,
  price REAL,
  currency TEXT,
  sku TEXT,
  stock INTEGER,
  image TEXT,
  description TEXT
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  customer_name TEXT,
  customer_phone TEXT,
  customer_city TEXT,
  customer_address TEXT,
  payment_method TEXT,
  total REAL,
  status TEXT,
  created_at TEXT,
  receipt_path TEXT
);

CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id TEXT,
  product_id TEXT,
  title TEXT,
  price REAL,
  qty INTEGER
);
`);

// seed
const row = db.prepare('SELECT count(1) as c FROM products').get();
if (row.c === 0) {
  const insert = db.prepare('INSERT INTO products (id,title,price,currency,sku,stock,image,description) VALUES (?,?,?,?,?,?,?,?)');
  insert.run('p1', 'Vestido floral - Shein', 79.99, 'USD', 'SH-001', 12, 'https://via.placeholder.com/600x800?text=Vestido+floral', 'Vestido ligero');
  insert.run('p2', 'Blusa casual - Shein', 29.99, 'USD', 'SH-002', 20, 'https://via.placeholder.com/600x800?text=Blusa+casual', 'Blusa de manga corta');
  insert.run('p3', 'Jeans tiro alto - Shein', 39.99, 'USD', 'SH-003', 8, 'https://via.placeholder.com/600x800?text=Jeans+tiro+alto', 'Jeans ajustados');
}

module.exports = db;
